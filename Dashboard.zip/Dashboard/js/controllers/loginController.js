(function () {
    angular.module("dashboard")
        .controller("loginController", function ($scope, dashboardFactory, $location, $timeout) {
            $scope.showPuzzleArea = false;
            $scope.userFieldError = false;
            $scope.loginDisable = true;
            $scope.showCompleError = false;
            $scope.imageNumber = 0;
            $scope.puzzleSuccess = false;

            $scope.onUserNameEnter = function ($event) {
                dashboardFactory.getUserDetails().then(function (data, status, headers, config) {
                    $scope.userDetailsList = data.users;
                    for (var i = 0; i < data.users.length; i++) {
                        if ($scope.userName) {
                            if ($scope.userName.toLowerCase() === data.users[i].username.toLowerCase() || $scope.userName.toLowerCase() === data.users[i].emalID.toLowerCase()) {
                                $scope.imageNumber = 0;
                                $scope.userDetails = data.users[i];
                                $scope.showNextImage();
                                $scope.showPuzzleArea = true;
                                $scope.userFieldError = false;
                                $timeout(function () {
                                    $scope.$emit("showCaptchaImagePuzzle", {});
                                }, 100);
                                $scope.$emit("startCountDown", {});
                                return;
                            } else {
                                $scope.userFieldError = true;
                            }
                        }
                    }

                }, function (data, status, headers, config) {
                    console.error("error", data);
                });
            };

            $scope.onPasswordEnter = function () {
                if ($scope.password && $scope.userName && $scope.puzzleSuccess) {
                    $scope.loginDisable = false;
                }
            };

            $scope.onLoginClick = function () {
                for (var i = 0; i < $scope.userDetailsList.length; i++) {
                    if ($scope.userName) {
                        if (($scope.userName.toLowerCase() === $scope.userDetailsList[i].username.toLowerCase() || $scope.userName.toLowerCase() === $scope.userDetailsList[i].emalID.toLowerCase()) && ($scope.password === $scope.userDetailsList[i].password )) {
                            sessionStorage.setItem('loginId', $scope.userName);
                            $scope.logoutBtn = true;
                            $location.path("/video_dashboard");
                            $scope.showCompleError = false;
                        } else {
                            $scope.showCompleError = true;
                        }
                    }
                }
            };

            $scope.showNextImage = function () {
                var capPuzzleDetails = $scope.userDetails.capPuzzle;
                if (capPuzzleDetails.length > $scope.imageNumber) {
                    $scope.img = $scope.userDetails.capPuzzle[$scope.imageNumber].image + '?' + new Date().getTime();
                } else {
                    $scope.imageNumber = 0;
                    $scope.img = $scope.userDetails.capPuzzle[$scope.imageNumber].image + '?' + new Date().getTime();
                }
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            };

            $scope.$on("timeUp", function () {
                $scope.imageNumber += 1;
                $scope.showNextImage();

                $timeout(function () {
                    $scope.$emit("reloadNextImage", {});
                    $scope.$emit("startCountDown", {});
                }, 100);
            });
            $scope.$on("successfullySolvedPuzzle", function () {
                $scope.puzzleSuccess = true;
                if ($scope.password && $scope.userName ) {
                    $scope.loginDisable = false;
                }
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
                return;
            });
        });
})();

